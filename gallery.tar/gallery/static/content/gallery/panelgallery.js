/* http://www.catchmyfame.com/2010/09/13/jquery-panel-gallery-2-0-released */
$(function(){
    $('.fancypanel').panelGallery({
        viewDuration: 3000,
        transitionDuration: 500,
        boxSize: 45,
        boxFadeDuration: 500,
        boxTransitionDuration: 50
	});
});



class Base(object):
    pass